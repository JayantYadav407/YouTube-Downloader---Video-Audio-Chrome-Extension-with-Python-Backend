from flask import Flask, request, jsonify
from yt_dlp import YoutubeDL
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

@app.route('/download', methods=['POST'])
def download_video():
    data = request.json
    youtube_url = data.get('youtube_url')
    output_filename = data.get('output_filename', 'output.mp4')  # Default filename if not provided
    download_type = data.get('download_type', 'video')  # Default to video

    # Validate URL
    if not youtube_url or not youtube_url.startswith(("https://www.youtube.com/", "https://youtu.be/")):
        return jsonify({"success": False, "message": "Invalid YouTube URL"}), 400

    # Save file to Desktop
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    output_path = os.path.join(desktop_path, output_filename)

    try:
        if download_type == "audio":
            options = {
                'format': 'bestaudio/best',
                'outtmpl': output_path,
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }]
            }
        else:  # Default to video
            options = {
                'format': 'bestvideo+bestaudio[ext=mp4]/mp4',
                'outtmpl': output_path,
                'merge_output_format': 'mp4',
            }

        with YoutubeDL(options) as ydl:
            ydl.download([youtube_url])

        return jsonify({"success": True, "message": f"{output_path}"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
