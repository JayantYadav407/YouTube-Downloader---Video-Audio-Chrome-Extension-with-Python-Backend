chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "download") {
    const youtubeUrl = message.url;

    // Check URL validity
    if (!youtubeUrl.startsWith("https://www.youtube.com/") && !youtubeUrl.startsWith("https://youtu.be/")) {
      sendResponse({ error: "Invalid YouTube URL." });
      return;
    }

    const outputPath = `${youtubeUrl.split("=")[1] || "video"}.mp4`;
    downloadYouTubeVideo(youtubeUrl, outputPath);
    sendResponse({});
  }
});

function downloadYouTubeVideo(youtubeUrl, outputPath) {
  chrome.downloads.download({
    url: `https://www.y2mate.com/youtube-url-to-download-api?video=${encodeURIComponent(youtubeUrl)}`,
    filename: outputPath,
    conflictAction: "uniquify"
  }, (downloadId) => {
    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError.message);
      return;
    }

    trackDownloadProgress(downloadId);
  });
}

function trackDownloadProgress(downloadId) {
  const updateInterval = setInterval(() => {
    chrome.downloads.search({ id: downloadId }, (results) => {
      if (results && results[0]) {
        const item = results[0];
        const progress = item.bytesReceived / item.totalBytes;
        console.log(`Download progress: ${(progress * 100).toFixed(2)}%`);
        
        if (item.state === "complete") {
          clearInterval(updateInterval);
          console.log("Download complete!");
        }
      }
    });
  }, 1000);
}
