document.getElementById("download-btn").addEventListener("click", () => {
  const youtubeUrl = document.getElementById("youtube-url").value.trim();
  const downloadType = document.getElementById("download-type").value; // Get the selected type (video or audio)

  // Validate YouTube URL
  if (!youtubeUrl.startsWith("https://www.youtube.com/") && !youtubeUrl.startsWith("https://youtu.be/")) {
    document.getElementById("status").innerText = "Invalid YouTube URL. Please try again.";
    document.getElementById("status").style.color = "red";
    return;
  }

  // Prompt user for file name
  const outputFileName = prompt("Enter desired file name (or leave blank for default):", downloadType === "audio" ? "audio.mp3" : "video.mp4")?.trim();

  // Update status
  document.getElementById("status").innerText = "Starting download...";
  document.getElementById("status").style.color = "black";

  // Send download request to backend
  fetch("http://127.0.0.1:5000/download", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      youtube_url: youtubeUrl,
      output_filename: outputFileName || (downloadType === "audio" ? "audio.mp3" : "video.mp4"),
      download_type: downloadType // Include the download type
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        document.getElementById("status").innerText = `Download complete! File saved at: ${data.message}`;
        document.getElementById("status").style.color = "green";
      } else {
        document.getElementById("status").innerText = `Error: ${data.message}`;
        document.getElementById("status").style.color = "red";
      }
    })
    .catch(error => {
      console.error("Error:", error);
      document.getElementById("status").innerText = "Failed to send the request. Ensure app.py is running.";
      document.getElementById("status").style.color = "red";
    });
});
